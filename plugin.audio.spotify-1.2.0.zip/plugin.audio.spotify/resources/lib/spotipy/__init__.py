from .client import Spotify, SpotifyException

VERSION = '2.0.1'
