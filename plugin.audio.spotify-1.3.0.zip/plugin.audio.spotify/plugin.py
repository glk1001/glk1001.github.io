#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
    plugin.audio.spotify
    Unofficial Spotify client for Kodi
"""

from resources.lib.plugin_content import PluginContent

if __name__ == "__main__":
    PluginContent()
